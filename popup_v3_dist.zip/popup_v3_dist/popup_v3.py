import tkinter as tk
from tkinter import font
from PIL import Image, ImageTk
import winsound


# Comando de cmd para crear el ejecutable: pyinstaller --onefile --icon=audib.ico "popup_v3.py"
# ..... O para la versión sin cmd visible: pyinstaller --onefile --noconsole --icon=audib.ico "popup_v3.py"
# ..... Para invocar un "no console" sin que truene: crear archivo run_silent.vbs: CreateObject("Wscript.Shell").Run "popup_v3.py", 0, True


def show_notification():
    root = tk.Tk()
    root.title("Notificación")
    root.geometry("425x120")
    root.configure(bg="#111111")
    root.resizable(False, False)
    root.overrideredirect(True)

    # ===== Borde animado =====
    #border_colors = ["#ff4d4d", "#ff9933", "#ffff66", "#66ff66", "#66ffff", "#6666ff"]
    border_colors = ["#820000", "#747474" ]
    border_index = 0

    border_frame = tk.Frame(root, bg=border_colors[0], padx=2, pady=2)
    border_frame.pack(fill="both", expand=True)

    inner = tk.Frame(border_frame, bg="#111111")
    inner.pack(fill="both", expand=True)

    # ---- Imagen ----
    #img = Image.open("icon.png")
    #img = img.resize((80, 80), Image.LANCZOS)
    #img_tk = ImageTk.PhotoImage(img)

    #img_label = tk.Label(inner, image=img_tk, bg="#111111")
    #img_label.image = img_tk
    #img_label.place(x=15, y=15)

    # ---- Imagen con borde gris ----
    img = Image.open("icon.png")
    img = img.resize((80, 80), Image.LANCZOS)
    img_tk = ImageTk.PhotoImage(img)

    # Frame que funciona como borde
    img_border = tk.Frame(inner, bg="#3F3F3F", padx=1, pady=1)
    img_border.place(x=13, y=13)

    img_label = tk.Label(img_border, image=img_tk, bg="#111111")
    img_label.image = img_tk
    img_label.pack()



    # ---- Fuentes ----
    title_font = font.Font(family="Segoe UI", size=14, weight="bold", slant="italic")
    desc_font = font.Font(family="Segoe UI", size=10, slant="italic")
    close_button_font = font.Font(family="Segoe UI", slant="italic")

    # ---- Título ----
    title_label = tk.Label(
        inner,
        text="Hora de :^)",
        bg="#111111",
        fg="white",
        font=title_font,
        anchor="w",
    )
    title_label.place(x=110, y=20)

    # ---- Descripción ----
    desc_label = tk.Label(
        inner,
        text="Ya llegó la hora de :^)",
        bg="#111111",
        fg="white",
        font=desc_font,
        anchor="w",
        justify="left",
    )
    desc_label.place(x=110, y=50)

    # ---- Botón Cerrar ----
    """
    close_button = tk.Button(
        inner,
        text="Cerrar",
        command=root.destroy,
        bg="#444444",
        fg="white",
        activebackground="#666666",
        activeforeground="white",
        relief="flat",
        padx=10,
        pady=3,
        font=close_button_font,
    )
    close_button.place(x=345, y=76)
    """
    
    # ---- Botón con borde gris ----
    button_border = tk.Frame(inner, bg="#9E9E9E", padx=1, pady=1)
    button_border.place(x=343, y=74)

    close_button = tk.Button(
        button_border,
        text="Cerrar",
        command=root.destroy,
        bg="#444444",
        fg="white",
        activebackground="#666666",
        activeforeground="white",
        relief="flat",
        padx=10,
        pady=3,
        font=close_button_font,
    )
    close_button.pack()


    
    # ---- Posición tipo toast ----
    root.update_idletasks()
    width = root.winfo_width()
    height = root.winfo_height()
    screen_w = root.winfo_screenwidth()
    screen_h = root.winfo_screenheight()

    x = screen_w - width - 20
    y = screen_h - height - 80
    root.geometry(f"{width}x{height}+{x}+{y}")

    # ===== Animación del borde =====
    def animate_border():
        nonlocal border_index
        border_index = (border_index + 1) % len(border_colors)
        border_frame.config(bg=border_colors[border_index])
        root.after(890, animate_border)# ..................................tiempo de cambio de colores

    animate_border()
    winsound.PlaySound("pop.wav", winsound.SND_FILENAME | winsound.SND_ASYNC)

    # ===== Hacer la ventana arrastrable =====
    def start_move(event):
        root.x = event.x
        root.y = event.y

    def stop_move(event):
        root.x = None
        root.y = None

    def do_move(event):
        deltax = event.x - root.x
        deltay = event.y - root.y
        x = root.winfo_x() + deltax
        y = root.winfo_y() + deltay
        root.geometry(f"+{x}+{y}")

    # Enlaza el movimiento AL FRAME INTERNO (para no romper tu borde animado)
    inner.bind("<ButtonPress-1>", start_move)
    inner.bind("<ButtonRelease-1>", stop_move)
    inner.bind("<B1-Motion>", do_move)



    root.mainloop()


show_notification()
